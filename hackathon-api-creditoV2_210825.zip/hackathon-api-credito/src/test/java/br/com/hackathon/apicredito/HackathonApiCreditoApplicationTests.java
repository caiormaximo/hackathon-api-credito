package br.com.hackathon.apicredito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackathonApiCreditoApplicationTests {

    @Test
    void contextLoads() {
    }

}
